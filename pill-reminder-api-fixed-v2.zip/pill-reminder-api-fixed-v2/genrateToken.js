require('dotenv').config();
const jwt = require('jsonwebtoken');

const generateToken = (user) => {
    const payload = {
        id: user.id,
        username: user.username,
        email: user.email,
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '24h' });

    return token;
};

// // Example usage
// const user = { id: 1, username: "john_doe", email: "john@example.com" };
// const token = generateToken(user);
// console.log("Generated JWT:", token);
