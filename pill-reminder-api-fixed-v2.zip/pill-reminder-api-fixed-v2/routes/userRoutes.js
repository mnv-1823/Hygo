const express = require("express");
const { getUsers, getUserById, createUser } = require("../controllers/userController");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router(); // Ensure router is defined properly

router.get("/allUsers", authMiddleware, getUsers);
router.get("/:id", authMiddleware, getUserById);
router.post("/", authMiddleware, createUser);

module.exports = router; // Ensure router is exported properly
